import FormPet, {formResult1} from './Form'
import Card from './Card'

function App() {
  //Aqui deberias agregar los estados y los handlers para los inputs
  
  return (
    <div className="App">
      <h1>Elige un color</h1>
      <FormPet />
      {formResult1 && <Card />}
    </div>
  );
}

export default App;
